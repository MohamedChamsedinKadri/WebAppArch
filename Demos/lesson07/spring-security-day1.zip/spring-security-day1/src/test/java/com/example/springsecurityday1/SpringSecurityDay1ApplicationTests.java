package com.example.springsecurityday1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityDay1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
