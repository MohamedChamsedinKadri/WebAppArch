package com.example.springsecurityday1.service;

import com.example.springsecurityday1.model.User;
import com.example.springsecurityday1.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CustomUserDetailService implements UserDetailsService {

    private final UserRepository userRepository;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//        return .;
        User u = userRepository.findByEmail(username);
        if (u == null) {
            throw new UsernameNotFoundException(username);
        } else {

            return org.springframework.security.core.userdetails.User
                    .withUsername(u.getEmail())
                    .password(u.getPassword())
                    .authorities(u.getRoles().stream().map(s -> new SimpleGrantedAuthority(s)).collect(Collectors.toList()))
//                    .roles(u.getRoles().stream().collect(Collectors.joining(","))) //ROLE_USER,ADMIN
                    .build();
        }
    }
}
