package com.example.springsecurityday1.controller;

import com.example.springsecurityday1.model.Product;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public List<Product> getProducts(){
        return Arrays.asList(
                Product.builder()
                        .id(1)
                        .name("DELL")
                        .build(),
                Product.builder()
                        .id(2)
                        .name("HP")
                        .build(),
                Product.builder()
                        .id(3)
                        .name("Acer")
                        .build()
        );
    }
}
