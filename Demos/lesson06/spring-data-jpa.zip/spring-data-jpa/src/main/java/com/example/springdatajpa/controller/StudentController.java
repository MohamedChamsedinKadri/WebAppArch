package com.example.springdatajpa.controller;

import com.example.springdatajpa.model.Student;
import com.example.springdatajpa.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/students")
public class StudentController {

    private final StudentService studentService;

    @GetMapping
    public List<Student> getStudents(@RequestParam int pageNumber, @RequestParam int pageSize){
        PageRequest pageRequest = PageRequest.of(pageNumber, pageSize);
        Page<Student> students = studentService.findByFirstName("Tom", pageRequest);
        Slice<Student> students2 = studentService.findByLastName("Jerry", pageRequest);
//        students2.
        return null;


        //        ages.forEach(System.out::println);
//        return studentService.findAllByAgeIn(ages);
//        if(firstName != null && !"".equals(firstName)){
//            return studentService.findByFirstName("%"+firstName);
//        } else {
//            return studentService.findAll();
//        }
    }

    @PostMapping
    public Student saveStudent(@RequestBody Student student){
        return studentService.save(student);
    }


    @GetMapping("/{queryString}")
    public Student findByZipCode(@PathVariable String queryString){
//        return studentService.findByAddress_ZipCode(zipCode);
//        return studentService.listByLastName(queryString);
        return studentService.listByFirstName(queryString);
    }
}
