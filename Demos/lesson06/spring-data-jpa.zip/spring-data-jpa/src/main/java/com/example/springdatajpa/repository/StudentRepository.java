package com.example.springdatajpa.repository;

import com.example.springdatajpa.model.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {
    List<Student> findAllByFirstNameContains(String firstName);

    List<Student> findAllByAgeIn(List<Integer> ages);

    Page<Student> findByFirstName(String firstName, Pageable pageable);
    Slice<Student> findByLastName(String lastName, Pageable pageable);

    Student findByAddressZipCode(String zipCode);

    Student findByAddress_ZipCode(String zipCode);

    @Query("select s from Student s where s.firstName = ?1") //HQL query based on object - use entity fileds/attributes
    Student listByFirstName(String firstName);

    @Query(value = "select * from student where last_name = :lastname", nativeQuery = true)
    Student listByLastName(@Param("lastname") String ddd);

}
