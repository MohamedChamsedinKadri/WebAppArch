package com.example.springdatajpa.service;

import com.example.springdatajpa.model.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.List;

public interface StudentService {

    List<Student> findAll();

    Student save(Student student);

    List<Student> findByFirstName(String firstName);

    List<Student> findAllByAgeIn(List<Integer> ages);

    Page<Student> findByFirstName(String firstName, Pageable pageable);

    Slice<Student> findByLastName(String lastName, Pageable pageable);

    Student findByAddressZipCode(String zipCode);

    Student findByAddress_ZipCode(String zipCode);

    Student listByFirstName(String firstName);

    Student listByLastName(String lastname);
}
