package com.example.springdatajpa.service;

import com.example.springdatajpa.model.Student;
import com.example.springdatajpa.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService{
    private final StudentRepository studentRepository;

    @Override
    public List<Student> findAll() {
        return studentRepository.findAll();
    }

    @Override
    public Student save(Student student) {
        return studentRepository.save(student);
    }

    @Override
    public List<Student> findByFirstName(String firstName) {
        return studentRepository.findAllByFirstNameContains(firstName);
    }

    @Override
    public List<Student> findAllByAgeIn(List<Integer> ages) {
        return studentRepository.findAllByAgeIn(ages);
    }

    @Override
    public Page<Student> findByFirstName(String firstName, Pageable pageable) {
        return studentRepository.findByFirstName(firstName, pageable);
    }

    @Override
    public Slice<Student> findByLastName(String lastName, Pageable pageable) {
        return findByLastName(lastName, pageable);
    }

    @Override
    public Student findByAddressZipCode(String zipCode) {
        return studentRepository.findByAddressZipCode(zipCode);
    }

    @Override
    public Student findByAddress_ZipCode(String zipCode) {
        return studentRepository.findByAddress_ZipCode(zipCode);
    }

    @Override
    public Student listByFirstName(String firstName) {
        return studentRepository.listByFirstName(firstName);
    }

    @Override
    public Student listByLastName(String lastname) {
        return studentRepository.listByLastName(lastname);
    }


}
