import {createStore, applyMiddleware, compose} from "redux";
import countReducer from './count-reducer';
import thunk from "redux-thunk";

const middlewareEnhancer = applyMiddleware(thunk);
const composeWithDevTools =
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const composedEnhancers = composeWithDevTools(middlewareEnhancer);
export default createStore(countReducer, composedEnhancers);
