import {useEffect, useRef, useState} from "react";
import store from '../../redux/store';
import {increment, decrement, addAsync} from "../../redux/count-slice";


export default function Count(){
    const [name, setName] = useState(null);

    const selectRef = useRef();

    const add = () => {
        store.dispatch(increment(selectRef.current.value * 1));
    }

    const substract = () => {
        store.dispatch(decrement(selectRef.current.value * 1));
    }

    const addIfOdd = () => {
        store.dispatch(increment(selectRef.current.value * 1));
    }

    const addAsyncHandler = () => {
        store.dispatch(addAsync({ value: selectRef.current.value * 1, delay: 2000 }));
    }

    return (
        <div>
            <h1>Count: {store.getState()}</h1>
            <select ref={selectRef}>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>&nbsp;&nbsp;
            <button onClick={add}>Increment</button> &nbsp;&nbsp;
            <button onClick={substract}>Decrement</button>&nbsp;&nbsp;
            <button onClick={addIfOdd}>IncrementIfOdd</button>&nbsp;&nbsp;
            <button onClick={addAsyncHandler}>IncrementAsync</button>&nbsp;&nbsp;
        </div>
    )
}