import {useEffect, useRef, useState} from "react";
import {connect} from "react-redux";
import store from '../../redux/store';
import {increment, decrement, addAsync} from "../../redux/count-slice";

function Count(props){
    console.log('props', props);
    const {count, add, substract, addAsync} = props;

    const selectRef = useRef(); // {current: select}

    const incrementHandler = () => {
        add(selectRef.current.value * 1);
    }

    const decrementHandler = () => {
        substract(selectRef.current.value * 1);
    }

    const incrementIfOddHandler = () => {
        if(count % 2 !== 0){
            add(selectRef.current.value * 1);
        }
    }

    const incrementAsyncHandler = () => {
        addAsync({ value: selectRef.current.value * 1, delay: 2000 });
    }

    return (
        <div>
            <h1>Count: {count}</h1>
            <select ref={selectRef}>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>&nbsp;&nbsp;
            <button onClick={incrementHandler}>Increment</button> &nbsp;&nbsp;
            <button onClick={decrementHandler}>Decrement</button>&nbsp;&nbsp;
            <button onClick={incrementIfOddHandler}>IncrementIfOdd</button>&nbsp;&nbsp;
            <button onClick={incrementAsyncHandler}>IncrementAsync</button>&nbsp;&nbsp;
        </div>
    )
}

export default connect(
    state => ({count: state}),
    ({
        add: increment,
        substract: decrement,
        addAsync
    })
)(Count);