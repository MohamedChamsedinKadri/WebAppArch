import {createSlice} from "@reduxjs/toolkit";

const initialState = 0;
const slice = createSlice({
    name: 'countday2',
    initialState,
    reducers:{
        increment(state, action){
            return state + action.payload;
        },
        decrement(state, action){
            return state - action.payload;
        }
    }
});

export const {increment, decrement} = slice.actions;
export default slice.reducer;