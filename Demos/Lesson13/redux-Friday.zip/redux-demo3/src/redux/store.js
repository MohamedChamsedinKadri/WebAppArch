import {configureStore} from "@reduxjs/toolkit";

import countReducer from './count-slice';

export default configureStore({
    reducer: countReducer
});
