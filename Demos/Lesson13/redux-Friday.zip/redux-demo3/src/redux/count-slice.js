import {createSlice, createAsyncThunk} from "@reduxjs/toolkit";

const initialState = 0;

const delayOperation = (value, delay) => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(value);
        }, delay);
    });
};

export const addAsync = createAsyncThunk(
    'count/addAsync',
    async ({ value, delay }) => {
        const response = await delayOperation(value, delay);
        return response;
    }
);

const countSlice = createSlice({
   name: 'count',
    initialState,
   reducers: {
       increment(state, action){
           console.log(state, action);
            const {payload} = action;
            return state + payload;
        },
       decrement(state, action){
           const {payload} = action;
           return state - payload;
       }
   },
    extraReducers: (builder) => {
        builder
            .addCase(addAsync.fulfilled, (state, action) => {
                return state + action.payload;
            });
    },
});

export const {increment, decrement} = countSlice.actions;
export default countSlice.reducer;
