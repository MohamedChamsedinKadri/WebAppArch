import Count from "./components/Count/count";
import LoginUseState from "./components/Login/LoginUseState";
import LoginUseReducer from "./components/Login/LoginUseReducer";

export default function App(){
    return (
        <div>
            {/*<Count />*/}
            <LoginUseState />
            {/*< hr />*/}
            <LoginUseReducer />
        </div>
    );
}