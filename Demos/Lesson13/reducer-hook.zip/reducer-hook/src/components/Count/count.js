import React, { useReducer } from 'react';

const initialState = 0;
// The reducer function
function reducer(state, action) {
    const {type, data} = action;
    switch (type) {
        case 'increment':
            return state + data
        case 'decrement':
            return state - data
        case 'reset':
            return 0
        default:
            return initialState
    }
}

const Counter = () => {
    const [state, dispatch] = useReducer(reducer, initialState);

    return (
        <div>
            Count: {state}
            <br />
            <br/>
            <button onClick={() => dispatch({ type: 'increment', data: 3 })}>Increment</button>
            <button onClick={() => dispatch({ type: 'decrement',  data: 4})}>Decrement</button>
            <button onClick={() => dispatch({ type: 'reset',  data: 0})}>Reset</button>
        </div>
    );
};

export default Counter;