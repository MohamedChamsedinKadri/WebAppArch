import CountContainer from './containers/Count';
import store from './redux/store';

export default function App(){
    return (
        <div>
            <CountContainer/>
        </div>
    );
}