import {createStore, applyMiddleware, combineReducers} from "redux";
import {configureStore} from "@reduxjs/toolkit";
import allReducers from './reducers';

import thunk from "redux-thunk";


// export default createStore(allReducers, applyMiddleware(thunk));

export default configureStore({
    reducer: allReducers
})
