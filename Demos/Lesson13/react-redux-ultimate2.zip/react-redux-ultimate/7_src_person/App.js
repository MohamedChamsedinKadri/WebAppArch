import CountContainer from './containers/Count';
import PersonContainer from './containers/Person'

export default function App(){
    return (
        <div>
            <CountContainer/>
            <hr />
            <PersonContainer />
        </div>
    );
}