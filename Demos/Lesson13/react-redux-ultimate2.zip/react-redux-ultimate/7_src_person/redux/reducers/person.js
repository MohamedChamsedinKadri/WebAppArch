import {ADD_PERSON} from "../constants";

const initState = [{id: 1, name: 'John', age: 12}];
export default function personReducer(prevState = initState, action){
    const {type, data} = action;
    switch (type){
        case ADD_PERSON:
            return [...prevState, data];
        default:
            return prevState;
    }
}