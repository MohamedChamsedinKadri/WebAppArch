import {connect} from "react-redux";
import {useRef} from "react";
import {nanoid} from "nanoid";

import {createAddPersonAction} from '../../redux/actions/person';



function Person(props){
    console.log(props);
    const {people, add, count} = props;

    const nameRef = useRef();
    const ageRef = useRef();
    const addPerson = () => {
        const name = nameRef.current.value;
        const age = ageRef.current.value * 1;
        add({id: nanoid(), name, age});
        nameRef.current.value = "";
        ageRef.current.value = "";
    }

    return (
        <div>
            <h1>Person Component, Count Component state: {count}</h1>
            <input ref={nameRef} placeholder="input a name you like"/>
            <input ref={ageRef} placeholder="input your real age"/>
            <button onClick={addPerson}>Add a new Person</button>
            <ul>
                {people.map(p => <li key={p.id}>{p.id}, {p.name}, {p.age}</li>)}
            </ul>
        </div>
    );
}

export default connect(
    state => ({people: state.persons, count: state.count}),
    {add: createAddPersonAction}
)(Person);