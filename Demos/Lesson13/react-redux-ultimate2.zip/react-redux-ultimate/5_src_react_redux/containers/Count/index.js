import {connect} from "react-redux";
import CountUI from "../../components/Count";
import {createIncrementAction, createDecrementAction, createIncrementAsyncAction} from "../../redux/count-action";

const mapStateToProps = state => ({count: state});

function mapDispatchToProps(dispatch) { //map the function which used to dispatch action into props
    return ({
        add: (data) => dispatch(createIncrementAction(data)),
        substract: (data) => dispatch(createDecrementAction(data)),
        addAsync: (data, time) => dispatch(createIncrementAsyncAction(data, time))
    })
}


export default connect(mapStateToProps, mapDispatchToProps)(CountUI);

