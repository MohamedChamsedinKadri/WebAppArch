import {useEffect, useRef, useState} from "react";

export default function Count(props){
    const [name, setName] = useState(null);

    console.log('props', props);
    const {count,add, substract, addAsync} = props;

    const selectRef = useRef(); // {current: select}

    const increment = () => {
        add(selectRef.current.value * 1);
    }

    const decrement = () => {
        substract(selectRef.current.value * 1);
    }

    const incrementIfOdd = () => {
        if(count % 2 !== 0){
            add(selectRef.current.value * 1);
        }
    }

    const incrementAsync = () => {
        addAsync(selectRef.current.value * 1, 1000);
    }

    return (
        <div>
            <h1>Count: {count}</h1>
            <select ref={selectRef}>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>&nbsp;&nbsp;
            <button onClick={increment}>Increment</button> &nbsp;&nbsp;
            <button onClick={decrement}>Decrement</button>&nbsp;&nbsp;
            <button onClick={incrementIfOdd}>IncrementIfOdd</button>&nbsp;&nbsp;
            <button onClick={incrementAsync}>IncrementAsync</button>&nbsp;&nbsp;
        </div>
    )
}