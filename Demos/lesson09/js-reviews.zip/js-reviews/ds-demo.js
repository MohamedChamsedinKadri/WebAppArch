const arr = ['banana', 'apple', 'orange'];
const s1 = arr[0];
const s2 = arr[1];
const s3 = arr[2];

const [a1, a2, a3] = arr;
// console.log(a1, a2, a3);

const obj = {
    firstname: 'John',
    lastname: 'Smith',
    age: 18
}

const f = obj.firstname;
const l = obj.lastname;
const a = obj.age;

const {firstname, lastname, age} = obj;
console.log(firstname, lastname, age);

const {firstname:fname, lastname:lname, age:myage} = obj;
console.log(fname, lname, myage);







