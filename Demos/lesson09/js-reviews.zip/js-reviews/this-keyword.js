const obj = {
    group: 'MIU',
    students: ['John', 'Edward'],
    showList: function (){
        this.students.forEach((s) => {
            console.log(this.group, s);
        });
    }
}
obj.showList();






// const person = {
//     firstname: 'John',
//     sayHi: function () { //non-method function
//         console.log('Welcome, ', this.firstname);
//     }
// }
// person.sayHi.bind({x:1})();

// setTimeout(() => person.sayHi(), 3000);
// setTimeout(person.sayHi.bind(person), 3000);
// setTimeout(() => person.sayHi.call(person), 3000);
// setTimeout(() => person.sayHi.apply(person), 3000);

// function foo(arg1, arg2){
//     console.log('********************', this, arg1, arg2);
// }
// // foo();
// foo.call(person, 'banana', 545);
// foo.apply(person, ['banana', 545]);







