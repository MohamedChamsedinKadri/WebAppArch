const arr1 = [1,2,3];
const str = 'Hi';
const arr2 = ['Banana', 'Orange'];
const result = [...arr1, ...str, ...arr2];
console.log(result);
//[1,2,3,'H', 'i','Banana', 'Orange']

const person = { name: "John", age: 30 };
const additionalInfo = { city: "New York", job: "Engineer" };

const p = {...person, ...additionalInfo};
console.log(p);
