// function add(num1, num2) {
//     return num1 + num2;
// }
//
// const add2 = (num1, num2) => num1 + num2;
//
// const f1 =() => 'abc';
// const f2 = str => str.length;
//
// console.log(add2(2, 3));



//function declaration
// function foo(){ //hoisting (creating phase)
//     console.log('inside foo....');
// }

// function foo(arg){
//     console.log('1 arg:' + arg);
// }
// foo();
// function foo(arg1, arg2){
//     console.log('2 args:', arg1, arg2);
// }
//
// foo(1);
// const result = foo(1,2);
// console.log(result);
// let i;
// console.log(i);
//
// console.log('******************************************');
// //function expression
// bar(1,1);
// let bar = function(n1, n2) {
//     console.log(n1 + n2);
// }

