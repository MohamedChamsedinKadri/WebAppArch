import greet, {add, subtract} from './util.js';

console.log(add(1,1));
console.log(subtract(2,1));
console.log(greet('Josh'));