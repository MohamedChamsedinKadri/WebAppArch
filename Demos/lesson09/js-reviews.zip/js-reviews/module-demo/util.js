export const add = (a, b) => a + b;
export const subtract = (a, b) => a - b;

const greet = (name) => `Hello, ${name}!`;
export default greet;