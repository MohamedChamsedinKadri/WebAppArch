// const arr = [1, true, 'hello', [1,2,3], {x:1}];
// // console.log(arr);
//
// const arr2 = [1]; //Holely array
// // arr2[10] = 99; //length = index + 1
// // console.log(arr2.length);
//
// arr2.push(2);
// arr2.push(3);
// console.log(arr2);
// console.log(arr2.pop());
//
// //Stack -> LIFO, FILO -> push, pop
// //Queue -> FIFO, LILO -> push, shift
//
// const strArr = ['banana', 'apple', 'orange'];
// strArr.unshift('strawberry');
// console.log(strArr);
// // console.log(strArr.shift());
// console.log(strArr);
//
// const result = strArr.filter(function (elem, index, array){
//     return elem.includes('b');
// }); //higher-order function
// console.log(result);

const strArr = ['banana', 'apple', 'orange'];
strArr.unshift('strawberry');
const res2 = strArr.filter((elem, index, array) => {
    console.log(elem, index, array);
    return elem.includes('b');
}).map(e => e.length)
    .reduce((previousValue, currentValue) => previousValue + currentValue, 0);
console.log(res2);


