"use strict";
function f(){

    console.log('f start: ', index, str);
    if(true){
        var index = 10;
    } else {
        var str = "MIU";
    }
    console.log('f end: ', index, str);
    console.log(typeof index);
}
// f();

// console.log(parseInt("1dfds") > 7); //string compare a number if string cannot convert to number, always false
// // console.log(index, str);
//
// console.log('5.0' === 5);
// console.log('5' === 5);

// if(5-2){
//     console.log('Truthy');
// } else {
//     console.log('Falsy');
// }

const str1 = "I'm a string";
const str2 = 'I"m a string';
const str3 = `
    I'm a powerful string
    called Template Literal
`;
const str4 = new String('I"m a string');
console.log(str4.length);