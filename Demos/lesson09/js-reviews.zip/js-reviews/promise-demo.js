// console.log('start.....');
// new Promise(function(resolve, reject){
//     const f = Math.random();
//     console.log('inside - start', f);
//     if(f > 0.5) {
//         resolve('Success');
//     } else {
//         reject('Whooooooops!');
//     }
//     console.log('inside - end');
// }).then(data => {return data.length;})
//     .then(d2 => console.log(d2))
//     .catch(err => console.error(err))
//     .finally(() => console.log('finally'));
//
// console.log('end.....');


// const p1 = new Promise(resolve => resolve(2))
//     .then(data => {return data * 2})
//     .then(data => data * 2);
//
// p1.then(console.log)

