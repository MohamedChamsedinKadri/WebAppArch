// "use strict";
// function Student(firstname, lastname) {
//     //this keyword inside JS is NOT optional
//
//     //this = {}
//     this.fname = firstname; //implied global
//     this.lname = lastname;
//     this.getFname = function (){
//         return this.fname;
//     }
//     // return this;
// }
// Student.prototype.getLname = function (){
//     return this.lname;
// }
//
// const s1 = new Student('John', 'Smith');
// console.log(s1);
// console.log(s1.getFname());
// console.log(s1.getLname());
//
// const s2 = new Student('Edward', 'Friday');
// console.log(s2);
// console.log(s2.getFname());
// console.log(s2.getLname());



class Student {
    constructor(firstname, lastname) {
        this.firstname = firstname; //if we have setter using syntax set ***, call setter, not add property
        this.lastname = lastname;
    }

    set firstname(fname){
        console.log('*************');
        this.#fname = fname;
    }

    get firstname(){
        console.log('%%%%%%%%%%%%%')
        return this.fname;
    }
}
const s3 = new Student('John', 'Smith');

console.log(s3.fname);

// s3.firstname = 'Tina'; //method call, call setter
// console.log(s3.firstname);

