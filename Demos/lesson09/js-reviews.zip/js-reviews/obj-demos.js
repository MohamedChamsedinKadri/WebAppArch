const obj = {
    firstname: 'John',
    lastname: 'Smith',
    "my age": 18,
     foo: function () { //method
        console.log('foooooooo');
    },
    getMyAge(){
        return 18;
    }
}
console.log(obj.lastname);
console.log(obj['my age']);

obj.major = 'CS';

let depart = 'admission';
obj[depart] = depart;

/**
 * {
 *   firstname: 'John',
 *   lastname: 'Smith',
 *   'my age': 18,
 *   foo: [Function: foo],
 *   getMyAge: [Function: getMyAge],
 *   major: 'CS',
 *   depart: 'admission'
 * }
 */

// obj.foo();
// console.log(obj.getMyAge());

console.log(obj);


