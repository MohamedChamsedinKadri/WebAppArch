
var foo = function (){ //hoisting (creating phase)
    console.log('inside foo....');
}

var foo =  function(arg){
    console.log('1 arg:' + arg);
}

var foo =  function (arg1, arg2){
    console.log('2 args:', arg1, arg2);
}
foo();
foo(1);
foo(1,2);