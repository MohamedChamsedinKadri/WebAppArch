async function f(){
    console.log('---------');
    return 1;
}

const res = f();
console.log(res);