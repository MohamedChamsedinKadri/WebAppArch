package miu.cs.springmvcdemo2.controller;

import lombok.RequiredArgsConstructor;
import miu.cs.springmvcdemo2.model.Product;
import miu.cs.springmvcdemo2.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;

@Controller
@RequestMapping("/products")
@RequiredArgsConstructor
public class ProductController {
    private final ProductService productService;
    @GetMapping("/get")
    public String getProducts(Model model){
        model.addAttribute("products", productService.getProducts());
        return "products";
    } //view name

    @GetMapping("/getProduct")
    public String getProductById(@RequestParam(required = false, name = "productId") int id, Model model){
        model.addAttribute("product", Product.builder()
                .id(id) //return this
                .title("HP")
                .description("A little bit better")
                .price(699)
                .build());
        return "product";
    }

    @GetMapping("/{id}")
    public String getProductById2(@PathVariable int id, Model model){
        model.addAttribute("product", Product.builder()
                .id(id) //return this
                .title("HP")
                .description("A little bit better")
                .price(699)
                .build());
        return "product";
    }

    @GetMapping("/{prodId}/comments/{cid}")
    public String getProductCommentByProdIdAndCommentId(@PathVariable int prodId, @PathVariable int cid, Model model){
        model.addAttribute("product", Product.builder()
                .id(prodId) //return this
                .title(String.valueOf(cid))
                .description("A little bit better")
                .price(699)
                .build());
        return "product";
    }

    @PostMapping("/save")
    public String saveProd(){
        return "saveProduct";
    }
}
