package miu.cs.springmvcdemo2.controller;

import miu.cs.springmvcdemo2.model.Product;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Arrays;

@Controller
@RequestMapping("/user")
public class UserController {

    @RequestMapping("/get")
    public String getUser(Model model){
        Product p1 = new Product(1, "DELL", "Cheap but good Laptop", 500);
        Product p2 = Product.builder()
                .id(2) //return this
                .title("HP")
                .description("A little bit better")
                .price(699)
                .build(); //return Product
        var products = Arrays.asList(p1, p2);
        model.addAttribute("products", products);
        return "products";
    } //view name


    @RequestMapping("/save")
    public String saveUser(){
        return "saveProduct";
    }
}
