package miu.cs.springmvcdemo2.service;

import miu.cs.springmvcdemo2.model.Product;

import java.util.List;

public interface ProductService {

    public List<Product> getProducts();
}
