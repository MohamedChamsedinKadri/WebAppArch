package miu.cs.springmvcdemo2.service;

import miu.cs.springmvcdemo2.model.Product;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class ProductServiceImpl implements ProductService{
    public List<Product> getProducts(){
        Product p1 = new Product(1, "DELL", "Cheap but good Laptop", 500);
        Product p2 = Product.builder()
                .id(2) //return this
                .title("HP")
                .description("A little bit better")
                .price(699)
                .build(); //return Product
        return Arrays.asList(p1, p2);
    }
}
