package miu.cs.springmvcdemo2.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class Product {
    private int id;
    private String title;
    private String description;
    private double price;
}
