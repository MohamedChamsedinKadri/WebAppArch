package miu.cs.springmvcdemo2;

import miu.cs.springmvcdemo2.controller.ProductController;
import miu.cs.springmvcdemo2.service.ProductServiceImpl;

public class ProductControllerTest {

    public void testGetProducts(){
     ProductController productController = new ProductController(new ProductServiceImpl());
     productController.getProducts(1);
    }
}
