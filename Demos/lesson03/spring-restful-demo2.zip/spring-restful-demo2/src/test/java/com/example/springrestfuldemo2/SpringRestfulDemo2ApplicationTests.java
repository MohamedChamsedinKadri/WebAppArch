package com.example.springrestfuldemo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestfulDemo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
