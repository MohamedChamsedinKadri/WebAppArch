package com.example.springrestfuldemo2.controller;

import com.example.springrestfuldemo2.model.Product;
import com.example.springrestfuldemo2.model.Product2;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
public class ProductControllerURIVersioning {

    @GetMapping("/v1/products")
    public List<Product> getProducts() {
        return Arrays.asList(
                new Product(1, "HP", 888),
                new Product(2, "DELL", 666),
                new Product(3, "Apple", 333),
                new Product(5, "Acer", 999)
        );
    }

    @GetMapping("/v2/products")
    public List<Product2> getProducts2() {
        return Arrays.asList(
                new Product2(1, "HP", "Great", 888),
                new Product2(2, "DELL", "Great",666),
                new Product2(3, "Apple", "Great",333),
                new Product2(5, "Acer", "Great",999)
        );
    }
}
