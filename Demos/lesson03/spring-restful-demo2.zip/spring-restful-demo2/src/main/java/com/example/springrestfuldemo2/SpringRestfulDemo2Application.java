package com.example.springrestfuldemo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestfulDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestfulDemo2Application.class, args);
	}

}
