package com.example.springrestfuldemo2.controller;

import com.example.springrestfuldemo2.model.Product;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/products")
public class ProductController {

//    private List<Product> productList = Arrays.asList(
//            new Product(1, "HP", 888),
//            new Product(2, "DELL", 666),
//            new Product(3, "Apple", 333),
//            new Product(5, "Acer", 999)
//    );

    List<Product> productList = new ArrayList<>();

//    1. Get All
    @GetMapping
//    @ResponseBody
    public List<Product> getProductList(){
        return productList;
    }


//    2. Get a single one
    @GetMapping("/{id}")
    public Product getProductById(@PathVariable int id) throws Exception {
        Optional<Product> prod =  productList
                .stream()
                .filter(p -> p.getId() == id)
                .findFirst();
        if(prod.isPresent()) {
            return prod.get();
        } else {
            throw new Exception("Not Found");
        }
    }
//    3. Save a product
    @PostMapping("")
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void saveProduct(@RequestBody Product product){
        productList.add(product);
    }

//    4. Update a product
    @PutMapping("/{id}")
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void updateProduct(@PathVariable int id, @RequestBody Product product) throws Exception {
        Optional<Product> prod =  productList
                .stream()
                .filter(p -> p.getId() == id)
                .findFirst();
        if(prod.isPresent()) {
           var old = prod.get();
           old.setTitle(product.getTitle());
           old.setPrice(product.getPrice());
        } else {
            throw new Exception("Not Found");
        }
    }

//    5. Delete a product

    @DeleteMapping("/{id}")
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable int id){
        productList = productList.stream().filter(p -> p.getId() != id)
                .collect(Collectors.toList());
    }
}
