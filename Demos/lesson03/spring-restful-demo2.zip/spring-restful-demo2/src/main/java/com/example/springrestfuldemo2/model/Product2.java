package com.example.springrestfuldemo2.model;

public class Product2 {

    private int id;
    private String name;
    private String description;
    private double price;

    public Product2(int id, String name, String description, double price) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
    }

    public Product2() {
    }

    public static Product2Builder builder() {
        return new Product2Builder();
    }

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public double getPrice() {
        return this.price;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean equals(final Object o) {
        if (o == this) return true;
        if (!(o instanceof Product2)) return false;
        final Product2 other = (Product2) o;
        if (!other.canEqual((Object) this)) return false;
        if (this.getId() != other.getId()) return false;
        final Object this$name = this.getName();
        final Object other$name = other.getName();
        if (this$name == null ? other$name != null : !this$name.equals(other$name)) return false;
        final Object this$description = this.getDescription();
        final Object other$description = other.getDescription();
        if (this$description == null ? other$description != null : !this$description.equals(other$description))
            return false;
        if (Double.compare(this.getPrice(), other.getPrice()) != 0) return false;
        return true;
    }

    protected boolean canEqual(final Object other) {
        return other instanceof Product2;
    }

    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        result = result * PRIME + this.getId();
        final Object $name = this.getName();
        result = result * PRIME + ($name == null ? 43 : $name.hashCode());
        final Object $description = this.getDescription();
        result = result * PRIME + ($description == null ? 43 : $description.hashCode());
        final long $price = Double.doubleToLongBits(this.getPrice());
        result = result * PRIME + (int) ($price >>> 32 ^ $price);
        return result;
    }

    public String toString() {
        return "Product2(id=" + this.getId() + ", name=" + this.getName() + ", description=" + this.getDescription() + ", price=" + this.getPrice() + ")";
    }

    public static class Product2Builder {
        private int id;
        private String name;
        private String description;
        private double price;

        Product2Builder() {
        }

        public Product2Builder id(int id) {
            this.id = id;
            return this;
        }

        public Product2Builder name(String name) {
            this.name = name;
            return this;
        }

        public Product2Builder description(String description) {
            this.description = description;
            return this;
        }

        public Product2Builder price(double price) {
            this.price = price;
            return this;
        }

        public Product2 build() {
            return new Product2(this.id, this.name, this.description, this.price);
        }

        public String toString() {
            return "Product2.Product2Builder(id=" + this.id + ", name=" + this.name + ", description=" + this.description + ", price=" + this.price + ")";
        }
    }
}
