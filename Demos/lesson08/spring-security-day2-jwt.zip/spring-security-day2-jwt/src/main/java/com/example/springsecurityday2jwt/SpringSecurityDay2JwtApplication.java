package com.example.springsecurityday2jwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityDay2JwtApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityDay2JwtApplication.class, args);
    }

}
