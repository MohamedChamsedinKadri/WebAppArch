package com.example.springsecurityday2jwt.controller;

import com.example.springsecurityday2jwt.model.Product;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class ProductController {

    @GetMapping("/products/{id}")
    @ResponseBody
    public Product getById(@PathVariable int id){
        return Product.builder().id(id).name("DELL").build();
    }

}
