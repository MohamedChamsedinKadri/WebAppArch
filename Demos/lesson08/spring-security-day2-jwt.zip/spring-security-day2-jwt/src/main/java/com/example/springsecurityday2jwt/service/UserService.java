package com.example.springsecurityday2jwt.service;

import com.example.springsecurityday2jwt.model.User;

public interface UserService {

    public User save(User u);

}
