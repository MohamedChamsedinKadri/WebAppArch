package com.example.springsecurityday2jwt.controller;

import com.example.springsecurityday2jwt.model.User;
import com.example.springsecurityday2jwt.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    @PostMapping
    public User save(@RequestBody User u){
        return userService.save(u);
    }
}
