package com.example.springsecurityday2jwt.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Product {

    private int id;
    private String name;
}
