package com.example.springsecurityday2jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityDay2JwtApplicationTests {

    @Test
    void contextLoads() {
    }

}
