package com.example.springsecuritydemo2.model.api;

import lombok.Data;

@Data
public class AuthRequest {

    private String email;
    private String password;
}
