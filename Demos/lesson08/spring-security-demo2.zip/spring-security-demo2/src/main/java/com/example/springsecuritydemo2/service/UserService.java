package com.example.springsecuritydemo2.service;

import com.example.springsecuritydemo2.model.User;

import java.util.List;

public interface UserService {

    User saveUser(User user);
    List<User> getUsers();

}
