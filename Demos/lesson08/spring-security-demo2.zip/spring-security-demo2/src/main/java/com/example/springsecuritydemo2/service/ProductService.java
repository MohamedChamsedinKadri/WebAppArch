package com.example.springsecuritydemo2.service;

import com.example.springsecuritydemo2.model.Product;

import java.util.List;

public interface ProductService {

    public Product saveProduct(Product product);

    public List<Product> getAll();

}
