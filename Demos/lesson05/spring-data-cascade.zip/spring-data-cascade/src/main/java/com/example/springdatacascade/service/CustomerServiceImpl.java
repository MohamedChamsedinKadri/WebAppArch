package com.example.springdatacascade.service;

import com.example.springdatacascade.model.CreditCard;
import com.example.springdatacascade.model.Customer;
import com.example.springdatacascade.repository.CreditCardRepository;
import com.example.springdatacascade.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final CreditCardRepository creditCardRepository;

    @Override
    public Customer save(Customer c) {
        c.getCreditCards()
                .stream()
                .forEach(cc -> cc.setCustomer(c));
        return customerRepository.save(c);
    }

    @Override
    public List<Customer> getAll() {
        return customerRepository.findAll();
    }

    @Override
    public void deleteCreditCard(Long customerId, UUID creditCardId) throws Exception {
        Optional<Customer> optionalCustomer = customerRepository.findById(customerId);
        if (optionalCustomer.isPresent()) {
            Customer customer = optionalCustomer.get();
            customer.getCreditCards().removeIf(creditCard -> creditCard.getId().equals(creditCardId));
            customerRepository.save(customer);
        } else {
            throw new Exception("something wrong");
        }
    }
}
