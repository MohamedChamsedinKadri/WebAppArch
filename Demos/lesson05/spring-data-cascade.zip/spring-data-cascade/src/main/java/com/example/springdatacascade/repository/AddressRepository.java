package com.example.springdatacascade.repository;

import com.example.springdatacascade.model.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {
}
