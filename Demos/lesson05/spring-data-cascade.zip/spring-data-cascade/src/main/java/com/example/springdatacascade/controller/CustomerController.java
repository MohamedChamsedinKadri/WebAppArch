package com.example.springdatacascade.controller;

import com.example.springdatacascade.model.Customer;
import com.example.springdatacascade.repository.AddressRepository;
import com.example.springdatacascade.service.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/customers")
public class CustomerController {

    private final CustomerService customerService;
    private final AddressRepository addressRepository;

    @PostMapping
    public Customer saveCustomer(@RequestBody Customer c){

        return customerService.save(c);
    }

    @DeleteMapping("/{customerId}/creditcards/{creditCardId}")
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void deleteCreditCard(@PathVariable Long customerId, @PathVariable UUID creditCardId) throws Exception {
        customerService.deleteCreditCard(customerId, creditCardId);
    }

}
