package com.example.springdatacascade.service;

import com.example.springdatacascade.model.Customer;

import java.util.List;
import java.util.UUID;

public interface CustomerService {

    Customer save(Customer c);

    List<Customer> getAll();

    void deleteCreditCard(Long customerId, UUID creditCardId) throws Exception;
}
