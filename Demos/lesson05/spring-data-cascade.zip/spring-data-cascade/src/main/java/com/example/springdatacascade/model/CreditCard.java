package com.example.springdatacascade.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Data
public class CreditCard {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    private long no;
    private LocalDate expiredDate;

    @ManyToOne
    @JsonBackReference
    private Customer customer;


}
