package com.example.springdatacascade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataCascadeApplicationTests {

    @Test
    void contextLoads() {
    }

}
