package miu.cs.inheritancesingletable.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("checking")
public class CheckingAccount extends Account {
    private double overdraftLimit;
}
