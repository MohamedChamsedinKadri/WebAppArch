package miu.cs.inheritancesingletable.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("savings")
public class SavingsAccount extends Account {
    private double APY;
}

