package miu.cs.inheritancesingletable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InheritanceSingleTableApplicationTests {

    @Test
    void contextLoads() {
    }

}
