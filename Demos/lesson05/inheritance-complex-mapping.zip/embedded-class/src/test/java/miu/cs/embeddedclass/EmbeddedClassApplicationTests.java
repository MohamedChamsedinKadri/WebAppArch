package miu.cs.embeddedclass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmbeddedClassApplicationTests {

    @Test
    void contextLoads() {
    }

}
