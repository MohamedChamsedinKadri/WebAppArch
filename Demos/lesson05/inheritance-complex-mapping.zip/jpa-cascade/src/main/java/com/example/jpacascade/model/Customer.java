package com.example.jpacascade.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@Entity
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String firstName;
    private String lastName;

    @OneToMany(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinColumn(name = "customer_id")
    private List<CreditCard> creditCards = new ArrayList<>();

    @JsonManagedReference
//    @OneToOne(cascade = CascadeType.PERSIST, orphanRemoval = true)
    @OneToOne(mappedBy = "customer", cascade = CascadeType.ALL)//always orphanRemoval true
    private Address address;


    public void removeCreditCard(CreditCard card) {
        creditCards.remove(card);
        card.setCustomer(null);
    }

    public void addCreditCard(CreditCard cc){
       creditCards.add(cc);
       cc.setCustomer(this);
    }

    public void addAddress(Address address){
        this.setAddress(address);
        address.setCustomer(this);
    }

}
