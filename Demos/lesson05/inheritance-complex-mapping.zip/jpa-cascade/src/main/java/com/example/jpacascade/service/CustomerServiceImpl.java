package com.example.jpacascade.service;

import com.example.jpacascade.model.CreditCard;
import com.example.jpacascade.model.Customer;
import com.example.jpacascade.repository.CreditCardRepository;
import com.example.jpacascade.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CreditCardRepository creditCardRepository;

    @Override
    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    @Override
    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }

    @Override
    public void deleteCreditCard(Long customerId, Long creditCardId) {
        Optional<Customer> c = customerRepository.findById(customerId);
        Optional<CreditCard> cc = creditCardRepository.findById(creditCardId);

        if (c.isPresent() && cc.isPresent()) {
            var customer = c.get();
            CreditCard creditCard = cc.get();
            customer.removeCreditCard(creditCard);
            customerRepository.save(customer);
        } else {
            throw new NoSuchElementException("No customer found with ID: " + customerId);
        }
    }

    @Override
    public List<Customer> getAll() {
        return StreamSupport.stream(customerRepository.findAll().spliterator(), false)
                .toList();
    }

    @Override
    public Customer findById(Long id) {
        return customerRepository.findById(id).get();
    }
}
