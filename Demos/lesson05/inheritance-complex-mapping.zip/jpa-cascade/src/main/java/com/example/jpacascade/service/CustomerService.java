package com.example.jpacascade.service;

import com.example.jpacascade.model.Customer;

import java.util.List;

public interface CustomerService {

    Customer saveCustomer(Customer customer);
    void deleteCustomer(Long id);

    void deleteCreditCard(Long customerId, Long creditCardId);

    List<Customer> getAll();

    Customer findById(Long id);
}
