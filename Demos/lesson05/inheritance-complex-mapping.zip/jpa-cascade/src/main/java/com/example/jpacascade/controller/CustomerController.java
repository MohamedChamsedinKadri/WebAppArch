package com.example.jpacascade.controller;

import com.example.jpacascade.model.Address;
import com.example.jpacascade.model.CreditCard;
import com.example.jpacascade.model.Customer;
import com.example.jpacascade.service.CustomerService;
import com.example.jpacascade.service.CustomerServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@RequestMapping("/customers")
@RestController
public class CustomerController {

    @Autowired
    private CustomerService customerService;
    @PostMapping
    public Customer saveCustomer() {
        Customer c = new Customer();
        c.setFirstName("John");
        c.setLastName("Smith");
        var address = Address.builder().street("1000 N 10th St")
                .apt("Unit 2")
                .city("Fairfield")
                .state("IA")
                .zip("52557").build();
        c.addAddress(address);

        var cc1 = CreditCard.builder().no(4147202211110909L).expiredDate(LocalDate.of(2025, 11, 21)).build();
        c.addCreditCard(cc1);

        var cc2 = CreditCard.builder().no(4147202211112222L).expiredDate(LocalDate.of(2024, 8, 11)).build();
        c.addCreditCard(cc2);

        var cc3 = CreditCard.builder().no(4147202211113333L).expiredDate(LocalDate.of(2025, 3, 5)).build();
        c.addCreditCard(cc3);

        return customerService.saveCustomer(c);
    }


    @DeleteMapping("/{id}")
    public void deleteCustomer(@PathVariable Long id){
        customerService.deleteCustomer(id);
    }

    @DeleteMapping("/{cid}/credit-cards/{ccid}")
    public void deleteCreditCard(@PathVariable("cid") Long customerId, @PathVariable("ccid") Long creditCardId){
        customerService.deleteCreditCard(customerId, creditCardId);
    }

    @GetMapping
    public List<Customer> getAll(){
        return customerService.getAll();
    }

    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable Long id){
        return customerService.findById(id);
    }

}
