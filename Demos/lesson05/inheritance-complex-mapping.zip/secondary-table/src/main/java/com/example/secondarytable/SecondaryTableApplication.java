package com.example.secondarytable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondaryTableApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecondaryTableApplication.class, args);
    }

}
