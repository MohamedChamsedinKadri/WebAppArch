package com.example.secondarytable.model;

import jakarta.persistence.*;

@Entity
//@SecondaryTable(name="Warehouse")
@SecondaryTables({
        @SecondaryTable(name="Warehouse", pkJoinColumns= {
                @PrimaryKeyJoinColumn(name="product_id", referencedColumnName="number")
        }),
        @SecondaryTable(name="Address", pkJoinColumns= {
                @PrimaryKeyJoinColumn(name="item_id", referencedColumnName="number")
        })}
)
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long number;
    private String name;
    private double price;
    @Column(table = "Warehouse")
    private boolean available;

    @Column(table = "Address")
    private String address;
}

