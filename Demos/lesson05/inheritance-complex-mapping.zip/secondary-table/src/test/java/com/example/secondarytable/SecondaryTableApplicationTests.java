package com.example.secondarytable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondaryTableApplicationTests {

    @Test
    void contextLoads() {
    }

}
