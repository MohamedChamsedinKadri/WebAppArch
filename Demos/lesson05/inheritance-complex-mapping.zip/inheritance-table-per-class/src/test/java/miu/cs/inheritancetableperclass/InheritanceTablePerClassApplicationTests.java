package miu.cs.inheritancetableperclass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InheritanceTablePerClassApplicationTests {

    @Test
    void contextLoads() {
    }

}
