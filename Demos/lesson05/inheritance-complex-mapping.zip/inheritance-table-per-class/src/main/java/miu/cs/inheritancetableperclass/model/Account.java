package miu.cs.inheritancetableperclass.model;

import jakarta.persistence.*;

@Entity
@Inheritance(strategy= InheritanceType.TABLE_PER_CLASS)
public abstract class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE) // or Auto because Auto is Table by default
    private Long number;
    private double balance;

}