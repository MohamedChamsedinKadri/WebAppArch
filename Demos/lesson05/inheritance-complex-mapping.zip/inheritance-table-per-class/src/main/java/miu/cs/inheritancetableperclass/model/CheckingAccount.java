package miu.cs.inheritancetableperclass.model;

import jakarta.persistence.Entity;

@Entity
public class CheckingAccount extends Account {
    private double overdraftLimit;
}
