package miu.cs.inheritancetableperclass.model;

import jakarta.persistence.Entity;

@Entity
public class SavingsAccount extends Account {
    private double APY;
}