package miu.cs.compositekeys.controller;

import miu.cs.compositekeys.model.Employee;
import miu.cs.compositekeys.model.Name;
import miu.cs.compositekeys.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.Local;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;


    @PostMapping("/employees")
    public Employee saveEmployee(@RequestBody Employee employee){
//        Name name = new Name("Tina", "Xing");
//        Employee employee = new Employee(name, LocalDate.now());
        return employeeService.saveEmployee(employee);
    }


}
