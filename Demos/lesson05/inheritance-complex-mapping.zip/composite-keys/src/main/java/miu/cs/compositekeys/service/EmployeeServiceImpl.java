package miu.cs.compositekeys.service;

import miu.cs.compositekeys.model.Employee;
import miu.cs.compositekeys.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService{

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public Employee saveEmployee(Employee employee) {
        employee.getProjects()
                .forEach(p -> p.setOwner(employee));
        return employeeRepository.save(employee);
    }
}
