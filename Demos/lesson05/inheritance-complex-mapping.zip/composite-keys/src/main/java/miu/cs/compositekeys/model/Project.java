package miu.cs.compositekeys.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "Emp_firstname", referencedColumnName = "firstname"),
            @JoinColumn(name = "Emp_lastname", referencedColumnName = "lastname")
    })
    @JsonBackReference
    private Employee owner;

}
