package miu.cs.compositekeys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompositeKeysApplication {

    public static void main(String[] args) {
        SpringApplication.run(CompositeKeysApplication.class, args);
    }

}
