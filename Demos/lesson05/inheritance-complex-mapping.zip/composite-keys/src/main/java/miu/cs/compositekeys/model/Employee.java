package miu.cs.compositekeys.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Employee {

    @EmbeddedId
    private Name name;

    private LocalDate startDate;

    @OneToMany(mappedBy="owner", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Project> projects
            = new ArrayList<>();

}