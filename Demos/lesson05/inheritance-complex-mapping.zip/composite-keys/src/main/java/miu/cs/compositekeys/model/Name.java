package miu.cs.compositekeys.model;

import jakarta.persistence.Embeddable;
import lombok.*;

import java.io.Serializable;

@Embeddable
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Name implements Serializable {
    private String firstName;
    private String lastName;

}
