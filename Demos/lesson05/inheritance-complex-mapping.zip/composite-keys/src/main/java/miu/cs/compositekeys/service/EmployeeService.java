package miu.cs.compositekeys.service;

import miu.cs.compositekeys.model.Employee;

public interface EmployeeService {

    public Employee saveEmployee(Employee employee);

}
