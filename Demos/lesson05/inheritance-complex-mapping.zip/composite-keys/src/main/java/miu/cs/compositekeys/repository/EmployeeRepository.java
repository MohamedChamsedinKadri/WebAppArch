package miu.cs.compositekeys.repository;

import miu.cs.compositekeys.model.Employee;
import miu.cs.compositekeys.model.Name;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeRepository extends CrudRepository<Employee, Name> {
}
