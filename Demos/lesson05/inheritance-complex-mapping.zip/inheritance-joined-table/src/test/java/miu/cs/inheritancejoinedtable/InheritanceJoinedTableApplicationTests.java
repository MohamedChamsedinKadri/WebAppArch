package miu.cs.inheritancejoinedtable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InheritanceJoinedTableApplicationTests {

    @Test
    void contextLoads() {
    }

}
