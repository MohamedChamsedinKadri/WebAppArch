package miu.cs.inheritancejoinedtable.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
public class CheckingAccount extends Account {
    private double overdraftLimit;
}
