package miu.cs.inheritancejoinedtable.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
public class SavingsAccount extends Account {
    private double APY;
}