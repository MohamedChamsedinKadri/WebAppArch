package miu.cs.inheritancejoinedtable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InheritanceJoinedTableApplication {

    public static void main(String[] args) {
        SpringApplication.run(InheritanceJoinedTableApplication.class, args);
    }

}
