package com.example.helloworld.model;



public record Rectangle(double length, double width) {

}

