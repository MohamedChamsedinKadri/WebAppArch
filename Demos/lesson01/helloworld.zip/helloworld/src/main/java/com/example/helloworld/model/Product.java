package com.example.helloworld.model;

import lombok.*;


//@NoArgsConstructor
//@AllArgsConstructor
@Data
public class Product {
    private int id;
    private String firstname;
    private String lastname;
    private int age;
}
