package com.example.helloworld.controller;

import com.example.helloworld.model.StudentBuilder;
import com.example.helloworld.model.StudentRecord;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeController {

    @GetMapping("/hello")
    public String greeting(String name){
        return "hello, " + name;
    }

    @GetMapping("/")
    public String greeting2(){
        return "Hi from Tina";
    }

}
