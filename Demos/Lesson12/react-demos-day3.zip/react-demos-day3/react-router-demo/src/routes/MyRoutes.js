import {useRoutes} from "react-router-dom";

import Home from "../pages/home";
import About from "../pages/about";
import NoMatch from "../pages/404";
import Posts from "../components/Posts";
import PostLists from "../components/PostLists";
import Post from "../components/Post";

export default function Routes() {
    const element = useRoutes([
        {path: "/", element: <Home/>},
        {
            path: "/posts",
            element: <Posts/>,
            children: [
                {index: true, element: <PostLists/>},
                {path: ":id", element: <Post/>}
            ],
        },
        {path: "/about", element: <About/>},
        {path: "*", element: <NoMatch/>}
    ]);
    return element;
}