export const blogPosts = [
    {id: 1, title: 'First Blog Post', description: 'Lorem ipsum dolor sit amet, consectetur adip.'},
    {id: 2, title: 'Second Blog Post', description: 'Lorem ipsum dolor sit amet, consectetur adip.'},
    {id: 3, title: 'Third Blog Post', description: 'Lorem ipsum dolor sit amet, consectetur adip.'}
];