import './App.css';
import {BrowserRouter as Router, Routes, Route, Link} from 'react-router-dom';
import MyRoutes from './routes/MyRoutes';
import Home from "./pages/home";
import Posts from "./components/Posts";
import PostLists from "./components/PostLists";
import Post from "./components/Post";
import About from "./pages/about";
import NoMatch from "./pages/404";


function App() {
    return (
        <Router>
            <nav style={{margin: 10}}>
                <Link to="/" style={{padding: 5}}>
                    Home
                </Link>
                <Link to="/posts" style={{padding: 5}}>
                    Posts
                </Link>
                <Link to="/about" style={{padding: 5}}>
                    About
                </Link>
            </nav>
            <MyRoutes/>
        </Router>
    );
}

export default App;
