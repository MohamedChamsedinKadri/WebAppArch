import {useParams} from "react-router-dom";
import {blogPosts} from '../data';

export default function Post() {
    const { id } = useParams();
    const post = blogPosts.find(b => b.id == id);

    if(!post) {
        return <span>The blog post you've requested doesn't exist.</span>;
    }
    const { title, description } = post;
    return (
        <div style={{ padding: 20 }}>
            <h3>{title}</h3>
            <p>{description}</p>
        </div>
    );
}