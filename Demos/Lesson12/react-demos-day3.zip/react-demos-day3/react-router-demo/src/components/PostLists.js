import {Link} from "react-router-dom";

import {blogPosts} from '../data';

export default function PostLists() {

    return (
        <ul>
            {blogPosts.map(b => (
                <li key={b.id}>
                    <Link to={`/posts/${b.id}`}>
                        <h3>{b.title}</h3>
                    </Link>
                </li>
            ))}
        </ul>
    );
}