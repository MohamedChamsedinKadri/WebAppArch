import './App.css';
import Timer from "./effect-hook/Timer";
import Counter from "./effect-hook/Counter";
import CleanUp from "./effect-hook/Cleanup";
import {useState} from "react";
import NewMyComponent from "./new/context/MyComponent";








function App() {
    const [isActive, setIsActive] = useState(true);
    return (
        <div className="App">
            <NewMyComponent />
            {/*{isActive && <CleanUpDemo />}*/}
            {/*<button onClick={() => setIsActive(false)}>Unmount CleanUpDemo</button>*/}
        </div>
    );
}

export default App;
