import {useEffect, useState} from "react";

export default function CleanUp(){
    const [count, setCount] = useState(0);

    useEffect(() => {
        const timerId = setInterval(() => {
            console.log('setInterval...');
            setCount(count + 1);
        }, 1000);
        return () => clearInterval(timerId);
    }, [count]);

    return <h1>I've rendered {count} times!</h1>
}