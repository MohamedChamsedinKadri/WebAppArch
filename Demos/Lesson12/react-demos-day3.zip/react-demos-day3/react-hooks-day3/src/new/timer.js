import {useEffect, useState} from "react";

export default function NewTimer(){
    const [count, setCount] = useState(0);

    //componentDidMount
    useEffect(() => {
        setTimeout(() => {
            setCount(count + 1);
        }, 3000);
    }, []);

    return <h1>This page is rendered {count} times!!</h1>;
}