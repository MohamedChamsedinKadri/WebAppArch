import {useState} from "react";
import NewComponent5 from "./Component5";
import {UserContext} from './context';
export default function NewMyComponent() {
    const [user, setUser] = useState("John Smith!!!");

    return (
        <UserContext.Provider value={user}>
            <>
            <h1>{`Hello ${user}!`}</h1>
            <Component2 user={user} />
            </>
        </UserContext.Provider>
    );
}

function Component2({ user }) {
    return (
        <>
            <h1>Component 2</h1>
            <Component3 user={user} />
        </>
    );
}

function Component3({ user }) {
    return (
        <>
            <h1>Component 3</h1>
            <Component4 user={user} />
        </>
    );
}

function Component4({ user }) {
    return (
        <UserContext.Provider value="Hello from React">
            <h1>Component 4</h1>
            <NewComponent5 user={user} />
        </UserContext.Provider>
    );
}



