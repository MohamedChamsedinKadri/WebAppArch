import {useContext} from "react";
import {UserContext} from "./context";

export default function NewComponent5() {
    // const user = useContext(UserContext);
    return (
        <UserContext.Consumer>
            {
                user => (
                    <>
                        <h1>NewComponent5 5</h1>
                        <h1>Hello, {user} again</h1>
                    </>
                )
            }
        </UserContext.Consumer>
    );
}