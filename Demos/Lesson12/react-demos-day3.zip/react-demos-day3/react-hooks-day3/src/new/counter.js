import {useEffect, useState} from "react";

export default function NewCounter(){
    const [count, setCount] = useState(0);
    const [calculation, setCalculation] = useState(0);

    useEffect(() => {
        setCalculation(count * 3);
    }, [count]);

    return (
        <div>
            <h1>Count: {count}</h1>
            <button onClick={() => setCount(count + 1)}>+1</button>
            <h1>Calculation: {calculation}</h1>
        </div>
    )
}