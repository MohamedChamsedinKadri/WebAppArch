import {useEffect, useState} from "react";

export default function CleanUpDemo(){
    const [count, setCount] = useState(0);

    useEffect(() => {
       const timerId = setInterval(()=>{
            console.log('setInterval.....');
            setCount(count + 1);
        }, 1000);
        return () => clearInterval(timerId);
    }, []);
    return (
        <div>
            <h1>Count: {count}</h1>
        </div>
    )
}