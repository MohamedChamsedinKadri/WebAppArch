import {createContext} from "react";

export const UserContext = createContext("This is default value.");