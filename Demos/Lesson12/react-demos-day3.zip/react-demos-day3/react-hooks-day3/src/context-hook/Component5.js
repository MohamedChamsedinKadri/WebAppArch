import {useContext} from "react";
import {UserContext} from "./context";


// export default function Component5() {
//     const user = useContext(UserContext);
//     return (
//         <>
//             <h1>Component 5</h1>
//             <h2>{`Hello ${user} again!`}</h2>
//         </>
//     );
// }

export default function Component5() {

    return (
        <UserContext.Consumer>
            {user => (
                <>
                    <h1>Component 5 Consumer</h1>
                    <h2>{`Hello ${user} again!`}</h2>
                </>
            )}
        </UserContext.Consumer>
    );
}