import './App.css';
import StudentList from "./components/StudentList";
import AddStudent from "./components/AddStudent";
import Student from "./components/Student";
import "bootstrap/dist/css/bootstrap.min.css";
import {BrowserRouter, Routes, Route, Link} from "react-router-dom";
import StudentListOld from "./components-bk/StudentList";
import AddStudentOld from "./components-bk/AddStudent";


function App2(){
    return (
       <>
           <StudentListOld />
           <AddStudentOld />
       </>
    )
}
function App() {


    return (
        <BrowserRouter>
            <div>
                <nav className="navbar navbar-expand navbar-dark bg-dark">
                    <a href="/students" className="navbar-brand">
                        WAA
                    </a>
                    <div className="navbar-nav mr-auto">
                        <li className="nav-item">
                            <Link to={"/students"} className="nav-link">
                                Students
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link to={"/add"} className="nav-link">
                                Add
                            </Link>
                        </li>
                    </div>
                </nav>

                <div className="container mt-3">
                    <Routes>
                        <Route path="/" element={<StudentList/>} />
                        <Route path="/students" element={<StudentList/>} />
                        <Route path="/add" element={<AddStudent/>} />
                        <Route path="/students/:id" element={<Student/>} />
                    </Routes>
                </div>
            </div>
        </BrowserRouter>
    );
}

export default App;
