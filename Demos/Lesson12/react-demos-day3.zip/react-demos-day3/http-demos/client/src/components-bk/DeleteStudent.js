import axios from "axios";
import {useState} from "react";
export default function DeleteStudentOld() {
    const [result, setResult] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const handleDeleteRequest = async () => {
        setLoading(true);
        try{
            const response = await axios.delete('http://localhost:8080/students/2');
            console.log(response);
            setResult(true);
            setLoading(false);
        } catch(err){
            setError(err);
            setLoading(false);
        }
    }

    return (
        <div>
            <h1>React Axios DELETE Example</h1>
            <button onClick={handleDeleteRequest}>Make DELETE Request</button>
            {loading && <p>Loading...</p>}
            {error && <p>Error: {error.message}</p>}
            {result && (
                <div>
                    <h2>DELETE Request Success</h2>
                </div>
            )}
        </div>
    );

}