import axios from "axios";
import {useState} from "react";
export default function EditStudentOld() {
    const [result, setResult] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const handlePostRequest = async () => {
        const postData = {
            "firstName": "Appleberry",
            "lastName": "USA",
            "age": 20
        };

        try{
            const response = await axios.put('http://localhost:8080/students/7', postData);
            setResult(response.data);
            setLoading(false);
        } catch(err){
            setError(err);
            setLoading(false);
        }

    }

    return (
        <div>
            <h1>React Axios UPDATE Example</h1>
            <button onClick={handlePostRequest}>Make UPDATE Request</button>
            {loading && <p>Loading...</p>}
            {error && <p>Error: {error.message}</p>}
            {result && (
                <div>
                    <h2>UPDATE Request Result:</h2>
                    <pre>{JSON.stringify(result, null, 2)}</pre>
                </div>
            )}
        </div>
    );

}