import {useState, useEffect} from "react";
import axios from "axios";

export default function StudentListOld(){

    const [students, setStudents] = useState([]);
        useEffect( () => {
            (async () => {
                const response = await axios.get('http://localhost:8080/students');
                setStudents(response.data);
            })();
        }, [])



    return (
        <div>
            <h1>React Axios Example</h1>
            <ul>
                {students.map(s => (
                    <li key={s.id}>{s.firstName}, {s.lastName}, {s.age}</li>
                ))}
            </ul>
        </div>
    );
}
