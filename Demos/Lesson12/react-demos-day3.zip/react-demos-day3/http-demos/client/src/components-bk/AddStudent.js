import axios from "axios";
import {useState} from "react";
export default function AddStudentOld() {
    const [postResult, setPostResult] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const handlePostRequest = async () => {
        const postData = {
            "firstName": "Appleberry",
            "lastName": "US",
            "age": 30
        };

        try{
            const response = await axios.post('http://localhost:8080/students', postData);
            setPostResult(response.data);
            setLoading(false);
        } catch(err){
            setError(err);
            setLoading(false);
        }

    }

    return (
        <div>
            <h1>React Axios POST Example</h1>
            <button onClick={handlePostRequest}>Make POST Request</button>
            {loading && <p>Loading...</p>}
            {error && <p>Error: {error.message}</p>}
            {postResult && (
                <div>
                    <h2>POST Request Result:</h2>
                    <pre>{JSON.stringify(postResult, null, 2)}</pre>
                </div>
            )}
        </div>
    );

}