import {useState, useEffect} from "react";
import {Link} from "react-router-dom";

import StudentService from "../services/StudentService";


function StudentList(){
    const [students, setStudents] = useState([]);
    const [currentStudent, setCurrentStudent] = useState(null);
    const [currentIndex, setCurrentIndex] = useState(-1);

    useEffect(() => {
        retrieveStudents();
    }, []);


    const retrieveStudents = () => {
        StudentService.getAll()
            .then(response => {
                setStudents(response.data);
                console.log(response.data);
            })
            .catch(e => {
                console.log(e);
            });
    };

    const refreshList = () => {
        retrieveStudents();
        setCurrentStudent(null);
        setCurrentIndex(-1);
    };

    const setActiveTutorial = (student, index) => {
        setCurrentStudent(student);
        setCurrentIndex(index);
    };



    return (
        <div className="list row">

            <div className="col-md-6">
                <h4>Student List</h4>

                <ul className="list-group">
                    {students &&
                        students.map((s, index) => (
                            <li
                                className={
                                    "list-group-item " + (index === currentIndex ? "active" : "")
                                }
                                onClick={() => setActiveTutorial(s, index)}
                                key={index}
                            >
                                {s.firstName}, {s.lastName}, {s.age}
                            </li>
                        ))}
                </ul>


            </div>
            <div className="col-md-6">
                {currentStudent ? (
                    <div>
                        <h4>Student</h4>
                        <div>
                            <label>
                                <strong>Firstname:</strong>
                            </label>{" "}
                            {currentStudent.firstName}
                        </div>
                        <div>
                            <label>
                                <strong>Lastname:</strong>
                            </label>{" "}
                            {currentStudent.lastName}
                        </div>
                        <div>
                            <label>
                                <strong>Age:</strong>
                            </label>{" "}
                            {currentStudent.age}
                        </div>

                        <Link
                            to={"/students/" + currentStudent.id}
                            className="btn btn-danger"
                        >
                            Edit
                        </Link>
                    </div>
                ) : (
                    <div>
                        <br />
                        <p>Please click on a Student...</p>
                    </div>
                )}
            </div>
        </div>
    );
}

export default StudentList;