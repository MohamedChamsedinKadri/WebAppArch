import {useNavigate, useParams} from "react-router-dom";
import {useState, useEffect} from "react";
import StudentService from "../services/StudentService";


function Student() {
    const {id} = useParams();
    let navigate = useNavigate();

    const initialStudentState = {
        id: null,
        firstName: "",
        lastName: "",
        age: ""
    };
    const [currentStudent, setCurrentStudent] = useState(initialStudentState);
    const [message, setMessage] = useState("");

    const getStudent = id => {
        StudentService.get(id)
            .then(response => {
                setCurrentStudent(response.data);
                console.log(response.data);
            })
            .catch(e => {
                console.log(e);
            });
    };

    useEffect(() => {
        if (id)
            getStudent(id);
    }, [id]);

    const handleInputChange = event => {
        const {name, value} = event.target;
        setCurrentStudent({...currentStudent, [name]: value});
    };

    const updateStudent = () => {
        StudentService.update(currentStudent.id, currentStudent)
            .then(response => {
                console.log('update', response.data);
                setMessage("The tutorial was updated successfully!");
            })
            .catch(e => {
                console.log(e);
            });
    };

    const deleteStudent = () => {
        StudentService.remove(currentStudent.id)
            .then(response => {
                console.log(response.data);
                navigate("/students");
            })
            .catch(e => {
                console.log(e);
            });
    };

    return (

        <div className="edit-form">
            <h4>Student</h4>
            <form>
                <div className="form-group">
                    <label htmlFor="firstName">FirstName</label>
                    <input
                        type="text"
                        className="form-control"
                        id="firstName"
                        name="firstName"
                        value={currentStudent.firstName}
                        onChange={handleInputChange}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="lastName">LastName</label>
                    <input
                        type="text"
                        className="form-control"
                        id="lastName"
                        name="lastName"
                        value={currentStudent.lastName}
                        onChange={handleInputChange}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="age">Age</label>
                    <input
                        type="text"
                        className="form-control"
                        id="age"
                        name="age"
                        value={currentStudent.age}
                        onChange={handleInputChange}
                    />
                </div>

            </form>

            <button className="btn btn-danger" onClick={deleteStudent}>
                Delete
            </button>

            <button
                type="submit"
                className="btn btn-danger"
                onClick={updateStudent}
            >
                Update
            </button>
            <p>{message}</p>
        </div>
    );
}

export default Student;