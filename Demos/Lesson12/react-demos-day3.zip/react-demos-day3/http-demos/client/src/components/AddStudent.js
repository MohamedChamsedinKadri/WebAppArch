import {useState} from "react";
import StudentService from "../services/StudentService";

export default function AddStudent() {
    const initialStudentState = {
        id: null,
        firstName: "",
        lastName: "",
        age: ""
    };
    const [student, setStudent] = useState(initialStudentState);
    const [submitted, setSubmitted] = useState(false);

    const handleInputChange = event => {
        const {name, value} = event.target;
        setStudent({...student, [name]: value});
    };

    const saveStudent = () => {
        let data = {
            firstName: student.firstName,
            lastName: student.lastName,
            age: student.age
        };

        StudentService.create(data)
            .then(response => {
                setStudent({
                    id: response.data.id,
                    firstName: response.data.firstName,
                    lastName: response.data.lastName,
                    age: response.data.age
                });
                setSubmitted(true);
                console.log(response.data);
            })
            .catch(e => {
                console.log(e);
            });
    };

    const newTutorial = () => {
        setStudent(initialStudentState);
        setSubmitted(false);
    };

    return (
        <div className="submit-form">
            {submitted ? (
                <div>
                    <h4>You submitted successfully!</h4>
                    <button className="btn btn-success" onClick={newTutorial}>
                        Add
                    </button>
                </div>
            ) : (
                <div>
                    <div className="form-group">
                        <label htmlFor="firstName">FirstName</label>
                        <input
                            type="text"
                            className="form-control"
                            id="firstName"
                            required
                            value={student.firstName}
                            onChange={handleInputChange}
                            name="firstName"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="lastName">LastName</label>
                        <input
                            type="text"
                            className="form-control"
                            id="lastName"
                            required
                            value={student.lastName}
                            onChange={handleInputChange}
                            name="lastName"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="age">Age</label>
                        <input
                            type="text"
                            className="form-control"
                            id="age"
                            required
                            value={student.age}
                            onChange={handleInputChange}
                            name="age"
                        />
                    </div>

                    <button onClick={saveStudent} className="btn btn-success">
                        Submit
                    </button>
                </div>
            )}
        </div>
    );

}