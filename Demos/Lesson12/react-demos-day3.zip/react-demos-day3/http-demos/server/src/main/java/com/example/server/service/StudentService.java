package com.example.server.service;

import com.example.server.model.Student;
import java.util.List;
import java.util.Optional;

public interface StudentService {

    List<Student> findAll();

    Student findById(int id) throws Exception;

    Student save(Student student);

    void deleteById(int id);

    Student updateStudent(int id, Student student);


}
