package com.example.onetoone.model;

import jakarta.persistence.*;

@Entity
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String street;
    private String apt;
    private String city;
    private String state;
    private String zip;

    @OneToOne(mappedBy="address")
    private Customer customer;

}
