package com.example.manytoone.model;

import jakarta.persistence.*;

@Entity
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private short year;
    private String model;
    private String maker;
    @ManyToOne
//    @JoinColumn(name="customer_id")
    @JoinTable(name="car_customer",
            joinColumns = { @JoinColumn(name = "customer_id") },
            inverseJoinColumns = { @JoinColumn(name = "car_id") })
    private Customer owner;

}
