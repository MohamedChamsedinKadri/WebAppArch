package com.example.manytomany.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class SalesPerson {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String alias;
    private String phoneNr;

    @ManyToMany
    private List<Customer> customers
            = new ArrayList<>();

}
