package com.example.bionetomay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiOneToMayApplicationTests {

    @Test
    void contextLoads() {
    }

}
