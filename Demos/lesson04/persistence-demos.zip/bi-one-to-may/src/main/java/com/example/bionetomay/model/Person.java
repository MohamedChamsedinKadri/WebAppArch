package com.example.bionetomay.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Person {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String firstname;
    private String lastname;
//    @OneToMany(mappedBy = "person")
    @OneToMany
    @JoinColumn(name = "person_id")
    private List<Car> cars =
            new ArrayList<>();


}
