package com.example.bionetomay.model;

import jakarta.persistence.*;

@Entity
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private short year;
    private String model;
    private String maker;
    @ManyToOne
//    @JoinTable(name = "person_car",
//            joinColumns = {@JoinColumn(name = "car_id")}, inverseJoinColumns = {@JoinColumn(name = "person_id")})
    private Person person;


}
