package com.example.bionetomay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiOneToMayApplication {

    public static void main(String[] args) {
        SpringApplication.run(BiOneToMayApplication.class, args);
    }

}
