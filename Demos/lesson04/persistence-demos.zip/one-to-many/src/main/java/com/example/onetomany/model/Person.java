package com.example.onetomany.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Person {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String firstname;
    private String lastname;
    @OneToMany
//    @JoinTable(name = "person_car", joinColumns = @JoinColumn(name = "person_id"), inverseJoinColumns = @JoinColumn(name = "car_id"))
    @JoinColumn(name = "person_id")
    private List<Car> cars = new ArrayList<>();

}
