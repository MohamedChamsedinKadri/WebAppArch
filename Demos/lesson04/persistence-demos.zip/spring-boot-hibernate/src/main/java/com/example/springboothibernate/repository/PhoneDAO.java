package com.example.springboothibernate.repository;

import com.example.springboothibernate.model.Employee;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PhoneDAO extends CrudRepository<Employee, Long> {
}

