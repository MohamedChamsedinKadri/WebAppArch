package com.example.springbootjdbc.services;

import com.example.springbootjdbc.model.Employee;
import com.example.springbootjdbc.repository.EmployeeDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService{

    @Autowired
    private EmployeeDAO employeeDAO;

    @Override
    public int addEmplyee(int id, String firstname, String lastname, String address) {
        return employeeDAO.addEmplyee(id, firstname, lastname, address);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employeeDAO.getAllEmployees();
    }
}
